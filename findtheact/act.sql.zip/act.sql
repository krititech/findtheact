-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 03, 2013 at 07:15 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `act`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `eventname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `skill` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`slno`, `eventname`, `name`, `location`, `skill`, `date`) VALUES
(3, '5', 'samaltopaz', 'rourkela', '6', '2013-08-24 12:08:03'),
(4, '6', 'marriage', 'bbsr', '6', '2013-08-24 12:24:01'),
(5, '5', 'samaltopaz', 'rourkela', '6', '2013-08-24 12:54:11');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL,
  `ip_address` varchar(40) NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `last_activity` int(40) NOT NULL,
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('0249f17bb15ff320ce8e286c61043b05', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206344, ''),
('02f3c937295fe8f93e864d9746295f5b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212700, ''),
('07bb4abebeb13471b800cba4b1feb922', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208378, ''),
('0805d951d63c869985f3e9ffaa563af4', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207374, ''),
('098bf1cbf72859ebc8a0baad07336244', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206368, ''),
('0aded9b93e91a5708dc603bbf6a900e9', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208694, ''),
('0b2dd229afc6ba3717c3d20341983d7e', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207353, ''),
('0bbe97c97f5d060625c0f0c6dc7af507', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207708, ''),
('0d2e3bf910525ea3c4e9976a49bb42a6', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208570, ''),
('0d573a12969bcb63cafd7e18771dc8cc', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207445, ''),
('0eab8ade2e66833ed3f70f899362d2f6', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207471, ''),
('14cf5c5c0f0011e4aee0cdb36d99a841', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206271, ''),
('15bd785b4e8a3acf62d23fae2316db53', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208490, ''),
('1854ddd0c850da3775fc667ef6fa5611', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210989, ''),
('1c59c6bb1130be9e95bb9d690ed373fa', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213225, ''),
('20295ca36ab6195b5e5f4be8a45d0d84', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206787, ''),
('223dd84003ff6689aa9bb9ad8f1f7638', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210301, ''),
('2249205c5f8a1fd2042c40658ab41d28', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211108, ''),
('226049572350391325f224782b3697d8', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207717, ''),
('22dfad280019d321a3181fb449e66486', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208272, ''),
('2382ab325581a1c5e47fd4e748d4812b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206353, ''),
('25a9167f9a513a1b5bd4404aba5c5553', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211108, ''),
('27cbcb6d1685ac79d8533566131133aa', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212689, ''),
('27cf5b6dc9ed6ca02809ff4d9ca2634a', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206768, ''),
('28dfdae07ae34710d28166653d055745', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206736, ''),
('2bae3ad86b3af620ef12d6d208927160', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208569, ''),
('2fa25350e8923bf70cf12fe34649309c', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207707, ''),
('33a7ebda181ba033700dc601b3e98e02', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212937, ''),
('354fef29eb99960253100f11246976a1', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207913, ''),
('37e98e7a70bb502352fbb0955fc97061', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213363, ''),
('39ea8a931b4b156ee11265bf998e9bc4', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208380, ''),
('3afe4dc98375226050f74407d26c945f', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213345, ''),
('3c58b4bfe70a7d73c737e9b8c4681020', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213196, ''),
('3c823007f6f82890426b49ca06b06bde', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212982, ''),
('3e90c66bb0b1a7bc28722bd65edd8a7f', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211311, ''),
('420682a379c92031f85a228f1fa4878b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206345, ''),
('45f6325bcabed714eb219fb1df7dcd44', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210433, ''),
('45f803aaacff7a9221edce2b302b0be4', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210988, ''),
('4e57211c06b5ebb1e7d137c005a4efcd', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210733, ''),
('53ce490fc6bafdb9fc64128fd4975f1e', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207889, ''),
('5713250f5d2b368b844c281b0246e8bd', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210707, ''),
('5cd215828b6643002933e5182a4af105', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213311, ''),
('5d7b9bef49ae091ee48376894709b19c', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206367, ''),
('5dd8b5e732cddcb461a70543b5bcab4b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213358, ''),
('5f8a27c351220bfe2f827eebb734560f', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212631, ''),
('6035b110ceffd86f4b1425eea91b75fa', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210961, ''),
('66aba22d9b058ea50571ec7d662c6c32', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211108, ''),
('6aa70a427a3530cc06eea892c15ec8ed', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213350, ''),
('6b4dc26ee216e70f723b99a93e10cc20', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213311, ''),
('6f0a732b2cca17d866340cf9f0ad3fd9', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210721, ''),
('71243b0673c3cfa7ed5c17d730b3a000', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206800, ''),
('737d2012412cabff83cbb16cfd96fd6b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207470, ''),
('795fea4abd70826b88c2aa4d0e5db142', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208168, ''),
('79912e8fefb50f812c36644e3e11cbbd', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206483, ''),
('7c3c91a91a1f4985e3927783e2e815cc', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206358, ''),
('829e1a9b7bcbdcb2360186cec9b039e2', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206358, ''),
('8323815747c8b7d052578b292a5c1873', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210199, ''),
('83757b8857990ce7390063d264572862', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208693, ''),
('847dee593a20b3579e1acf59ea59a4a2', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206892, ''),
('882d1987ff572a934cc6cee883fb2899', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206896, ''),
('888b23a6222d9c9eeb2cc91433c77f95', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206194, ''),
('904aa3fbd90c05ee5253a698f12a60a3', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210500, ''),
('9074b94e62a1a3762bca709ebceae336', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206147, ''),
('929c2df3a87f33df16b71e228204a5fa', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211754, ''),
('92d24d949af5a66cd9562dcfef63e822', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207685, ''),
('956b8d49ef211973b3d77a1823545d38', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208273, ''),
('96adc3ec2da0ba26f9d51a47a6d5a56b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210765, ''),
('a082310ceb6c5fe908d0c37abfcc389c', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212987, ''),
('a0b12b8c85fb8350ee59cff40800d5fa', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207935, ''),
('a0eb577d59c3fa3704ff87bb9a07e888', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212625, ''),
('a400032dc1478980a84be87390128eea', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212689, ''),
('ac5dec27dac1bd33215169ccf36aed45', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213356, ''),
('ac931a50d62768ee0f59ef8f3ebfa37e', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207479, ''),
('ae6071c8201b00886883a25e457fe551', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213350, ''),
('ae69ef0de2b6b33c18a456413fe45fa5', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210557, ''),
('af3c6676197f6b9fe390848dc93340e1', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213363, ''),
('b0e6b77a20a2ea41aa04d876f3abacfd', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212984, ''),
('b2170bb4956152a998b44e4303076489', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206938, ''),
('b4102140f4a05d4daf5a58fc84dc0478', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211401, ''),
('b4b8957acad65816a1195c903b087953', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206769, ''),
('b5978ebf87a43406fba467dabd9713f1', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208379, ''),
('b699778616a45cab6aab944f060992f0', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206773, ''),
('b7f88dc2ab3785e770a21416373b7e72', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206363, ''),
('b8b7e99123fa391658abf226690eaf10', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206895, ''),
('bbf7ae75e07a5618317eb9a401f9ee90', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378211311, ''),
('ca559734b6af5dbdf763005911b0e679', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206353, ''),
('cff622b97c3e859a908d46914f22f144', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206370, ''),
('d05fe677e913a8e13f0848016b5feac6', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212935, ''),
('d0f12180882c8a3662f854793bf4f3cc', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208241, ''),
('d33a86fe2c264950551ef630380aca29', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210613, ''),
('d52c7ce0bc91360fe62bf3009f54eb25', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213307, ''),
('d5d7a8f45b84789a85959c5171b42534', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213176, ''),
('de36f657641b0022b1b474de00d8f1fe', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213356, ''),
('e0df78c55178a6274aacf0bcb710a78d', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206345, ''),
('e11493f0b6f5d0bc6c5a3485aa59ce29', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212878, ''),
('e159e8f7c66c3e5fb34a39bc8e6e2c4e', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206484, ''),
('e76fbb4afdc35bf002c709805d0c8b1b', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208491, ''),
('ea727e7eaf82cf6887684d6e62fa2da5', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210988, ''),
('eba6df686c4a33d6cdf34ad6541fc1ec', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378210961, ''),
('efd9d292534b9f57cdaa3342ca959128', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378212700, ''),
('f5836027914cb6812e435880495fd795', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206891, ''),
('f58d57e4d08926bfad70eda2bf3e15bf', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207911, ''),
('f8962e2810f42ffeb48c52bf8a0f11e9', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206801, ''),
('f9c16a0c7925e100161ddd70c8627ea4', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378208492, ''),
('f9c48c9edb0ed7bc81065622ef5ee1d9', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378206141, ''),
('fc634c2869617c67a175e54604c1f8df', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378207352, ''),
('fdc02e1395c5ebae1371d84665af96b7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213353, ''),
('fedaa07063aecaef22e9ffba194eced2', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1378213172, '');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `eventname` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`slno`, `eventname`, `date`) VALUES
(5, 'Wedding', '2013-08-23 16:47:51'),
(6, 'Party', '2013-08-23 16:44:00');

-- --------------------------------------------------------

--
-- Table structure for table `eventmanager`
--

CREATE TABLE IF NOT EXISTS `eventmanager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `eventname` text NOT NULL,
  `mincost` float(12,2) NOT NULL,
  `maxcost` float(12,2) NOT NULL,
  `location` text NOT NULL,
  `skill` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `addedby` varchar(100) NOT NULL,
  `descp` text NOT NULL,
  `image` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `eventmanager`
--

INSERT INTO `eventmanager` (`id`, `name`, `eventname`, `mincost`, `maxcost`, `location`, `skill`, `date`, `addedby`, `descp`, `image`) VALUES
(1, 'act name', '6', 1000.00, 2000.00, 'bbsr', '5,6,', '2013-08-24 13:24:20', 'preetishree@gmail.com', 'At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies. ', 'actimages/1377330860.jpg'),
(2, 'act name2', '6', 5000.00, 6000.00, 'ctc', '6,7,', '2013-08-24 13:25:24', 'preetishree@gmail.com', 'At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies. ', 'actimages/1377330924.jpg'),
(3, 'act name44', '5', 1000.00, 2000.00, 'ctc', '5,6,', '2013-08-24 13:25:51', 'preetishree@gmail.com', 'At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies. ', 'actimages/1377330951.jpg'),
(4, 'my act', '6', 500.00, 1000.00, 'sbp', '5,6,7,', '2013-08-24 13:26:19', 'preetishree@gmail.com', 'At w3schools.com you will learn how to make a website. We offer free tutorials in all web development technologies. ', 'actimages/1377330979.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`slno`, `userid`, `password`, `type`) VALUES
(1, 'admin', 'admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `newletterstatus` int(15) NOT NULL,
  `confirm_code` varchar(30) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `username`, `email`, `pwd`, `status`, `date`, `newletterstatus`, `confirm_code`, `type`) VALUES
(1, 'preetishree', 'preetishree@krititech.in', '123456', 1, '2013-08-24 13:43:46', 1, 'ff7afab51064d080422d64cd7e1c21', 1),
(2, 'munmun jena', 'preetishree@gmail.com', '123123', 1, '2013-08-26 11:09:31', 1, '733ca0f913e14e64d74bddc1ce7b22', 2),
(3, '', '', '', 0, '2013-08-26 13:01:40', 0, '4f50ea785a0312bcef7f6739c6a210', 0);

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE IF NOT EXISTS `skill` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `skillname` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`slno`, `skillname`, `date`) VALUES
(5, 'Drama', '2013-09-03 18:32:43'),
(6, 'Songs', '2013-08-23 16:34:41'),
(7, 'Musical band', '2013-08-23 16:35:19'),
(8, 'skill1123', '2013-09-03 18:32:30');
