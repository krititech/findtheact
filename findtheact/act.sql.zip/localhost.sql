-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 21, 2013 at 08:46 PM
-- Server version: 5.1.66
-- PHP Version: 5.3.2-1ubuntu4.18

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `act`
--
CREATE DATABASE `act` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `act`;

-- --------------------------------------------------------

--
-- Table structure for table `actold`
--

CREATE TABLE IF NOT EXISTS `actold` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `eventname` text NOT NULL,
  `mincost` float(12,2) NOT NULL,
  `maxcost` float(12,2) NOT NULL,
  `location` text NOT NULL,
  `skill` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `addedby` varchar(100) NOT NULL,
  `descp` text NOT NULL,
  `image` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `actold`
--

INSERT INTO `actold` (`id`, `name`, `eventname`, `mincost`, `maxcost`, `location`, `skill`, `date`, `addedby`, `descp`, `image`) VALUES
(1, 'fgdfg', '8', 1222.00, 1121.00, 'bbsr', '5,6,', '2013-09-05 12:35:18', 'preetishree@gmail.com', 'dsfdsfsdf', 'profilepic1.jpg'),
(2, 'ghfghfgh', '6', 767.00, 78.00, 'yuuy', '7,8,', '2013-09-05 12:38:29', 'preetishree@gmail.com', 'ghghj', 'star1.png'),
(3, 'hjhgj', '5', 8779.00, 87978.00, 'hjikhjk', '6,', '2013-09-05 12:45:08', 'preetishree@gmail.com', 'hjkhjk', 'icon4.png'),
(4, 'dfggfg', '8', 12212.00, 323.00, 'sdsf', '7,8,', '2013-09-05 12:50:42', 'preetishree@gmail.com', 'sdfsf', 'shape.png'),
(5, 'khjk', '6', 78678.00, 787.00, 'yijhkhj', '5,6,', '2013-09-05 12:51:31', 'preetishree@gmail.com', 'hjkhjk', 'welcome.png'),
(6, 'khjk', '6', 78678.00, 787.00, 'yijhkhj', '5,6,', '2013-09-05 12:51:58', 'preetishree@gmail.com', 'hjkhjk', 'welcome.png'),
(7, 'khjk', '6', 78678.00, 787.00, 'yijhkhj', '5,6,', '2013-09-05 12:52:40', 'preetishree@gmail.com', 'hjkhjk', 'welcome.png'),
(8, 'khjk', '6', 78678.00, 787.00, 'yijhkhj', '5,6,', '2013-09-05 12:53:03', 'preetishree@gmail.com', 'hjkhjk', 'welcome.png'),
(9, 'jghjh', '8', 78678.00, 786.00, 'jhhjkhj', '7,8,', '2013-09-05 12:58:06', 'preetishree@gmail.com', 'hjkhkhjk', 'icon5.png'),
(10, 'jghjh', '8', 78678.00, 786.00, 'jhhjkhj', '7,8,', '2013-09-05 12:58:51', 'preetishree@gmail.com', 'hjkhkhjk', 'icon5.png');

-- --------------------------------------------------------

--
-- Table structure for table `agency_change`
--

CREATE TABLE IF NOT EXISTS `agency_change` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `act_id` varchar(500) NOT NULL,
  `under_agency` varchar(500) NOT NULL,
  `applied_to` varchar(300) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `agency_change`
--

INSERT INTO `agency_change` (`slno`, `act_id`, `under_agency`, `applied_to`, `status`) VALUES
(1, 'demo1@gmail.com', 'Rachel@flairentertainments.co.uk', 'madhusmita@krititech.in', 0),
(2, 'act@gmail.com', 'demo1@gmail.com', 'Rachel@flairentertainments.co.uk', 0);

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `eventname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `skill` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`slno`, `eventname`, `name`, `location`, `skill`, `date`) VALUES
(3, '5', 'samaltopaz', 'rourkela', '6', '2013-08-24 12:08:03'),
(4, '6', 'marriage', 'bbsr', '6', '2013-08-24 12:24:01'),
(5, '5', 'samaltopaz', 'rourkela', '6', '2013-08-24 12:54:11');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL,
  `ip_address` varchar(40) NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `last_activity` int(40) NOT NULL,
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES
('042edbdbbf04793166667a28f929a728', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381131280, ''),
('0870891704e01b546ed42862a0988455', '122.50.233.64', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381125173, ''),
('0874e7273c73b401a7f2f0c8b6ac371d', '122.50.233.64', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381125202, ''),
('0af18a62a9f3d043c59f5e2ec7b1340f', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130980, ''),
('0dd0688f3f825cf15f4c3537fa512c33', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625314, ''),
('15a918c879c01facbba4252ccf589b56', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130983, ''),
('1b56eaf05853266892d210d44621389d', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130955, ''),
('28a9468501e382fab1ce0348a9bbc3e3', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368626785, ''),
('2b537e0840461b81f7b29304489fd198', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130987, ''),
('30a8dc3aa6b39cdaa7c84bc9a0b3def8', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625313, ''),
('3f16940b1a1929a33cc58493f8600317', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625483, ''),
('5f65bca8d68edd4859ddd80601b68fb3', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381131258, ''),
('6242b1a045aefebd58974f2bf68f4e1d', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130980, ''),
('66aa9ca3beaca187fe418ec685d06495', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1381847873, ''),
('66e56f12a5a7e0fa3d7095d7c670ec82', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625656, ''),
('6ef1ee2823bb6484d18318e6f915d25a', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130964, ''),
('71b4111eb8451412c6d724914d5c60df', '122.50.233.64', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381124954, ''),
('7cb6fc9b15b3dc5910ce1127dcc2983c', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625497, ''),
('7e11be20b5d16baa2ee41c6c22f7f816', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381131272, ''),
('80ca80923e1b9245e5b3178795d43918', '122.50.233.64', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381125120, ''),
('8631d02bf3ce8084a5663e97dea3cea2', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1381847882, ''),
('89b89bceea72245a4728acc4365ca8a7', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130965, ''),
('ab81f4aa3828ccac97f10a433e235760', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381131279, ''),
('acc518a411d527712a74abd58dde7e68', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625321, ''),
('ae6f76ed96a9b6d11beca118b4113fc9', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625860, ''),
('b81ff5dbe27a6c4f0e23cc328df613ec', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625484, ''),
('c48b0a633781ca23591d101e6855e00b', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1368625497, ''),
('cc042b3953787d340b0a15f4d9901259', '122.50.233.64', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381125261, ''),
('d0a59e1c18d66767166d2f6c6f2e6162', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381130998, ''),
('d54bf9d8b319fde335a1359646a8e5e8', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381131505, ''),
('df2f494f62949f6dab26744eeea6fc7c', '115.250.133.102', 'Mozilla/5.0 (X11; Linux i686; rv:2.0) Ge', 1381847748, ''),
('f5add8df5b9e2ef04d628096e47a1820', '115.184.181.37', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381131504, ''),
('ffb4814ec7e9b8928ab26eb21b3a388e', '122.50.233.64', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv', 1381125172, '');

-- --------------------------------------------------------

--
-- Table structure for table `contact_details`
--

CREATE TABLE IF NOT EXISTS `contact_details` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `event` int(20) NOT NULL,
  `event_date` date NOT NULL,
  `starting_at` varchar(100) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` int(100) NOT NULL,
  `userid` int(11) NOT NULL,
  `freequoat` int(11) NOT NULL,
  `category_type` varchar(200) NOT NULL,
  `budget` varchar(200) NOT NULL,
  `full_name` varchar(300) NOT NULL,
  `comp_name` varchar(300) NOT NULL,
  `email` varchar(500) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contact_details`
--

INSERT INTO `contact_details` (`slno`, `event`, `event_date`, `starting_at`, `duration`, `city`, `state`, `zip`, `userid`, `freequoat`, `category_type`, `budget`, `full_name`, `comp_name`, `email`, `contact_no`, `password`, `datetime`) VALUES
(1, 5, '2013-08-12', '7', '17', 'bhubaneswar', 'Orissa', 752054, 2, 0, '6|', '$2000', 'madhusmita', 'kriti', 'madhusmita58@gmail.com', '9776888585', 'madhu', '2013-09-27 13:04:01'),
(2, 5, '2013-12-12', '15', '14', 'bbsr', 'odisha', 4567, 2, 10, '12|13|', '200', 'preetishree', 'krititech', 'preetishree@krititech.in', '43543564564', '123456', '2013-09-27 13:04:01'),
(3, 6, '2013-12-12', '3', '2', 'bhubneswar', 'odisha', 760912, 5, 5, '12|', '200', 'preetishree jena', 'krititech', 'preetishree@krititech.in', '23445455', '123456', '2013-09-27 13:26:09'),
(4, 8, '2013-09-02', '0', '4', 'df', 'sdf', 234234, 10, 5, '12|', '400', 'dsfkjsdl', ' sdfj ', 'jsulaiman@paycellsystems.com', '234234', '123', '2013-10-01 13:33:15');

-- --------------------------------------------------------

--
-- Table structure for table `diary`
--

CREATE TABLE IF NOT EXISTS `diary` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(500) NOT NULL,
  `ondate` date NOT NULL,
  `subject` varchar(500) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `diary`
--


-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `eventname` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`slno`, `eventname`, `date`) VALUES
(6, 'Party', '2013-08-23 16:44:00'),
(8, 'marraige', '2013-09-04 11:52:38');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`slno`, `userid`, `password`, `type`) VALUES
(1, 'admin', 'admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `professionalname` varchar(300) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `image` varchar(600) NOT NULL,
  `category` int(11) NOT NULL,
  `subcategory` int(11) NOT NULL,
  `zip` int(11) NOT NULL,
  `service` blob NOT NULL,
  `address` varchar(300) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `aboutus` text NOT NULL,
  `mincost` int(30) NOT NULL,
  `maxcost` int(30) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `added_by` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `professionalname`, `fname`, `lname`, `image`, `category`, `subcategory`, `zip`, `service`, `address`, `phone`, `email`, `password`, `aboutus`, `mincost`, `maxcost`, `date`, `added_by`) VALUES
(1, 'New England''s Own Rodney Dangerfield ', 'Rodney Dangerfield Impersonators', 'Boston Rodney Dangerfield Impersonators', 'test.jpg', 12, 12, 65804, 0x5477656e74792046697665207965617273206f66206c6f6f6b696e67206c696b652c20736f756e64696e67206c696b652c20616e6420616374696e67206c696b6520526f646e65792e204c617320566567617320323030352d2032303036202d323030372d203230303820436f72706f7261746520476f6c6620546f75726e616d656e747320416c6c204f7665722074686520436f756e74727920496e636c7564696e67204775616d20616e64205361692d70616e2e20436f6d65647920436c7562732c20436173696e6f732c20436f72706f7261746520616e6420507269766174652046756e6374696f6e7320616e64206d616e792046756e642072616973657227732e2048652068617320706572666f726d656420666f7220726164696f20616e642074656c65766973696f6e20616c6c206f7665722074686520636f756e74727920616e64207468652049736c616e6427732e205468697320736561736f6e6564206c6f6f6b2d612d6c696b6520696d706572736f6e61746f722068617320677261626265642074686520617474656e74696f6e206f66206576656e20526f646e657920616e64206869732077696665204a6f616e2c2054686579207765726520736f20696d7072657373656420776974682068697320706572666f726d616e6365207468617420746865792061736b65642068696d20746f20617474656e64206f6e65206f662044616e6765726669656c642773206e6577206d6f766965207072656d696572732e2042696c6c205065746572736f6e27732074696d696e67206973207065726665637420616e64206869732064656c697665727920697320696d7065636361626c6520616e642068652077696c6c206c6561766520796f7520616d617a656420616e64206c61756768696e67206879737465726963616c6c790a7777772e6262726f646e65792e636f6d, 'Boston, Massachusetts', '417-889-9909', 'jps.1391@gmail.com', 'lima', '0', 200, 300, '2013-09-16 18:20:38', ''),
(2, 'Infinity Circus Productions ', 'Aerialists', 'Atlanta Aerialists ', 'test1.jpg', 13, 6, 752054, 0x496e66696e697479204369726375732050726f64756374696f6e732069732074686520536f757468e2809973207072656d696572206576656e7420656e7465727461696e6d656e7420636f6d70616e792c2070726f766964696e672064796e616d69632063697271756520706572666f726d616e63657320666f72206c617267652d7363616c6520636f72706f7261746520656e7465727461696e6d656e742c2067616c61206576656e7473202620696e74696d6174652070726976617465207061727469657320616c696b652e204372656174697665204469726563746f722c204c69616e61205265706173732c206973206120686967686c7920747261696e656420617274697374207370656369616c697a696e6720696e2061657269616c2073696c6b732c2074726170657a652c206163726f6261746963732c2063686f72656f6772617068792c20616e64206576656e7420706c616e6e696e6720617373697374616e63652e2048657220736f6c6f20706572666f726d616e63657320616e642067726f75702070726f64756374696f6e7320636f6d62696e652072656d61726b61626c6520737472656e6774682c2065787472656d6520666c65786962696c6974792c20616e6420637265617469766974792e205468652067726163652026206172746973747279206f662068657220776f726b2077696c6c206d616b6520796f7572206576656e7420616e20756e666f726765747461626c65206f6e652120436f6e74616374204c69616e6120746f20696e71756972652061626f7574206372656174696e672061206d65736d6572697a696e67206164646974696f6e20746f20796f7572206576656e7420776974682041746c616e74612773206c656164696e672c2066756c6c7920696e73757265642067726f7570206f662070726f66657373696f6e616c2063697263757320617274697374732e, 'Atlanta, Georgia,bbsr', '9776888585', 'jps.1391@gmail.com', 'qwert', '0', 300, 400, '2013-10-02 10:56:55', 'demo1@gmail.com'),
(3, 'Off Centered ', 'Circus Entertainment', 'Atlanta Circus Entertainment', 'test2.jpg', 13, 6, 65804, 0x5765206172652061206d616c6520616e642066656d616c652064756f206163742e205765206f66666572207365766572616c2064756f20616e6420736f6c6f2063697263757320737461676520616e6420616d6269656e7420616374732c20696e636c7564696e672e2e2e0a0a506172746e6572204163726f62617469632042616c616e63696e6720416374732c0a466972653a2066616e732c206a7567676c696e6720746f72636865732c206669726520656174696e672026206669726520627265617468696e670a5374696c742077616c6b696e672c0a4a7567676c696e673a2062616c6c732c20636c7562732c204c4544732c20746f72636865732c0a526f6c6c6120426f6c6c612c0a44616e636520260a4163726f626174696373210a0a5765206f6666657220616c6c206f66206f757220736572766963657320617320616d6269656e7420656e7465727461696e6d656e7420616e64206861766520746872656520646966666572656e742063686f72656f6772617068656420737461676520726f7574696e657320746f20736574206d7573696320616e6420636f7374756d696e672061732077656c6c21204d6f737420616374732063616e20626520706572666f726d656420696e646f6f727320616e64206f757421, 'Atlanta, Georgia,bbsr', '417-889-9909', 'test@gmail.com', 'qewererer', '0', 500, 1000, '2013-09-16 18:20:38', ''),
(4, 'professional1', 'dsdsfdsf', 'sdfsfsd', 'sidebar3.jpg', 12, 12, 43345, 0x736466736466736466736466647366647366, 'fddsfsfsf', '546546546', 'testing@gmail.com', '123', '0', 300, 500, '2013-09-16 18:39:35', ''),
(5, 'Comedian in Birmingham', 'Bryan', 'Betz', '4c7829a901a96_large.jpeg', 6, 28, 128900, 0x5768657468657220796f75206869726520427279616e204265747a206f72206f7468657220436f6d656469616e7320696e204269726d696e6768616d20666f7220796f75722070617274792c2077656464696e672c206f72206576656e742c204769672053616c6164206d616b65732069742073757065722d6561737920746f20626f6f6b2070726f66657373696f6e616c20436f6d656469616e732e0a0a5765207374726f6e676c79207265636f6d6d656e64207468617420616c6c20636f6d6d756e69636174696f6e206265206b657074206f6e20746865204769672053616c616420426f6f6b696e6720506c6174666f726d20617320796f7520626f6f6b20796f757220436f6d656469616e2e205768656e20796f7520646f2c207765c3a2e282ace284a272652061626c6520746f206f66666572206e756d65726f75732062656e656669747320746861742077652063616ec3a2e282ace284a2742067756172616e74656520696620796f752074616b6520636f6d6d756e69636174696f6e206f72206465706f736974207061796d656e74206f666620746865204769672053616c616420706c6174666f726d2e204f757220626f6f6b696e672073797374656d206973206561737920746f2075736520616e642068616e646c657320736563757265206465706f736974207061796d656e74732066726f6d20796f7520746f20746865204269726d696e6768616d20436f6d656469616e206f6620796f75722063686f6963652e0a0a4164646974696f6e616c6c792c207468652071756f74652f61677265656d656e742073656e742066726f6d20796f757220436f6d656469616e20746f20796f75207573696e6720746865204769672053616c616420706c6174666f726d2c2073686f756c64206f75746c696e6520706572666f726d616e636520666565732c206578747261732c206172726976616c20616e64206465706172747572652074696d65732c2063616e63656c6c6174696f6e20706f6c6963792c20696e737572616e636520696e666f726d6174696f6e20616e64206f746865722064657461696c732e, 'Birmingham, AL', ' 417-889-9909888', 'Bryan@Bryan.com', '123456', '0', 100, 200, '2013-10-02 10:56:55', 'demo1@gmail.com'),
(6, 'Luke Murgatroyd', 'Luke', 'Murgatroyd', 'leekamen.jpg', 0, 0, 0, 0x61206d61676963616c2061637420, '12 harrow road', '01924950108', 'Luke@LukeMurgatroyd.co.uk', 'bedkingdom123', '0', 100, 10000, '2013-10-01 11:59:42', 'ashley@bedkingdom.co.uk'),
(7, 'sd', 'sandeep', 'nayak', 'img7.jpg', 5, 23, 0, 0x727265746572747265747265, 'fdgfdgdfg', '698989', 'sandeep@krititech.in', '123456', '0', 100, 300, '2013-10-01 12:07:40', 'Rachel@flairentertainments.co.uk'),
(8, 'sdfdsfsdf', 'rterte', 'ertret', 'sale.png', 5, 22, 5645, 0x727472657472657465727465727472657472, 'ertert', '564654', 'priti@gmail.com', '123456', '0', 100, 200, '2013-10-01 12:13:12', 'Rachel@flairentertainments.co.uk'),
(9, 'demo1', 'demotest', 'test', 'pfree.png', 0, 0, 4554, 0x7975797475747975747975797475, 'dfgdfg', '7665776', 'demo1@gmail.com', '123456', '0', 100, 200, '2013-10-01 12:20:20', 'Rachel@flairentertainments.co.uk'),
(10, 'acting', 'dfg', 'asdf', '0_010.jpg', 3, 12, 343434, 0x6173646b6a6b662073646620736466, 'sdf,f sf ', '417-889-9909 ', 'act@gmail.com', 'act', '0', 100, 500, '2013-10-01 13:29:06', 'demo1@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `newletterstatus` int(15) NOT NULL,
  `confirm_code` varchar(30) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `username`, `email`, `pwd`, `status`, `date`, `newletterstatus`, `confirm_code`, `type`) VALUES
(1, 'preetishree', 'preetishree@krititech.in', '123456', 1, '2013-09-06 11:43:44', 1, 'ff7afab51064d080422d64cd7e1c21', 1),
(2, 'Munmun jena', 'preetishree@gmail.com', '123123', 1, '2013-09-05 16:31:21', 1, '733ca0f913e14e64d74bddc1ce7b22', 2),
(4, 'dfdff', 'dfd@gmail.com', '55', 1, '2013-09-04 15:09:08', 1, '', 0),
(7, 'topaz', 'samaltopaz@gmail.com', 'samal', 1, '2013-09-04 15:12:33', 1, '', 0),
(8, 'hghjhg', '55551ghjghjghj', 'qwertyhgjgj', 1, '2013-09-04 15:29:13', 1, 'fe8d6c5d32dff362a034fde767d810', 0),
(9, 'hjghj', '55551', 'qwerty', 1, '2013-09-04 16:22:39', 1, '3e6b606172dce67feb231aeab3ee56', 2),
(10, 'hjghj', '55551', 'qwerty', 1, '2013-09-04 16:22:39', 1, 'c83222f1868838a73e396ddeb9d0e9', 2),
(11, 'jyotiprava', 'jps.1391@gmail.com', 'lima', 0, '2013-09-16 17:28:46', 1, '', 2),
(12, 'professional1', 'testing@gmail.com', '123', 0, '2013-09-16 18:39:35', 0, '', 2),
(13, 'madhusmita', 'madhusmita@krititech.in', '123456', 0, '2013-09-26 12:34:58', 1, 'd2791038909f665019ca5966e5f020', 1),
(14, 'Comedian in Birmingham', 'Bryan@Bryan.com', '123456', 0, '2013-09-26 14:40:09', 0, '', 2),
(15, 'Flair', 'Rachel@flairentertainments.co.uk', 'beds09123', 0, '2013-10-01 11:51:27', 0, 'fe6d1b20aebb51681d5aee08f15c8b', 1),
(16, 'flair', 'ashley@bedkingdom.co.uk', 'bedkingdom123', 0, '2013-10-01 11:56:13', 0, 'c13bb8bd44f1eb787a780822d8458d', 1),
(17, 'Luke Murgatroyd', 'Luke@LukeMurgatroyd.co.uk', 'bedkingdom123', 0, '2013-10-01 11:59:42', 0, '', 2),
(18, 'actagency1', 'demo@gmail.com', '123456', 0, '2013-10-01 12:01:34', 1, '41675807a7becdda5a6b53381d3f94', 1),
(19, 'sd', 'sandeep@krititech.in', '123456', 0, '2013-10-01 12:07:40', 0, '', 2),
(20, 'sdfdsfsdf', 'priti@gmail.com', '123456', 0, '2013-10-01 12:13:12', 0, '', 2),
(21, 'demo1', 'demo1@gmail.com', '123456', 0, '2013-10-01 12:20:20', 0, '', 2),
(22, 'demo1@gmail.com', 'demo1@gmail.com', 'demo', 0, '2013-10-01 13:23:30', 0, 'f3e0dd34bf7e0ac3f2da3a181c9ec9', 1),
(23, 'acting', 'act@gmail.com', 'act', 0, '2013-10-01 13:29:06', 0, '', 2),
(24, 'bedkingdom', 'Ashley@bedkingdom.co.uk', 'bex09123', 0, '2013-10-02 15:54:02', 0, '48c8df6fabdeeafd32ef9a6276da7e', 1),
(25, 'agent', 'agent@aol.coms', 'agent123', 0, '2013-10-02 15:55:56', 0, 'be145c623a5ef48d75378a6ed31df8', 0),
(26, 'agent', 'agent@aol.coms', 'agent123', 0, '2013-10-02 15:56:13', 1, 'b9363ec6a0781d84dce2f541eb9222', 1),
(27, 'agent', 'agent@aol.coms', 'agent123', 0, '2013-10-02 15:56:47', 1, '3750ae18d3a399f925f922111ba549', 1);

-- --------------------------------------------------------

--
-- Table structure for table `replyquoats`
--

CREATE TABLE IF NOT EXISTS `replyquoats` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `replyto` varchar(500) NOT NULL,
  `replyfrom` varchar(500) NOT NULL,
  `subject` varchar(400) NOT NULL,
  `message` text NOT NULL,
  `reply_ondate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `replyquoats`
--

INSERT INTO `replyquoats` (`slno`, `replyto`, `replyfrom`, `subject`, `message`, `reply_ondate`) VALUES
(1, 'preetishree@krititech.in', 'demo1@gmail.com', 'hiiiii', 'accepted', '2013-10-07 07:34:39');

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE IF NOT EXISTS `skill` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `skillname` varchar(200) NOT NULL,
  `descp` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `image` varchar(500) NOT NULL,
  `typevalue` int(11) NOT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `skill`
--

INSERT INTO `skill` (`slno`, `skillname`, `descp`, `date`, `image`, `typevalue`) VALUES
(1, 'Bands', 'With over 80 different genres of bands and musical groups to choose from, it’s nearly impossible to leave without finding a band that you and your guests will wanna jam to.', '2013-09-21 13:16:28', 'icon_n_bands.png', 2),
(2, 'Children’s', 'There’s nothin’ better than knowing that you’ve made your child’s day, is there? Well… why not make their year (or even their childhood) by throwing a party they’ll never forget with these “rock-your-socks-off” entertainers.', '2013-09-21 13:17:41', 'icon_n_childrens.png', 2),
(3, 'Circus', 'Step right up to see the amazing contortionist! Or how about the death-defying trapeze artist? They’re all jaw-dropping, and these performers will dazzle you with three rings of fun.', '2013-09-21 13:18:08', 'icon_n_circusentertainment.png', 2),
(4, 'Classical', 'Dear sir or madam… if you want live classical music at your event, you’ve got class. You know the difference between “real” music and that stuff those hooligans are listening to nowadays.', '2013-09-21 13:18:31', 'icon_n_classical.png', 2),
(5, 'Comedy', 'Laughter is the best medicine. So is giggling, chuckling, guffawing, and even the occasional snorting.', '2013-09-21 13:18:54', 'icon_n_comedy.png', 2),
(6, 'Dance', 'You may know how to get jiggy with it, bust out a mean cha-cha slide or even do the robot. Even so, you might want to check out these professional dancers to light up your event.', '2013-09-21 13:19:22', 'icon_n_dance.png', 2),
(7, 'DJs', 'For a fresh spin on any party, book a DJ to drop beats and get your guests out of their seats and onto the dance floor.', '2013-09-21 13:21:36', 'icon_n_djs.png', 2),
(8, 'Impersonators', '“Thank you… thank you very much.” “Happy birthday, Mr. President.” “Hasta la vista, baby.” Yes… Elvis, Marilyn, and Ah-nold are just waiting to drop these lines at your next event.', '2013-09-21 13:21:34', 'icon_n_impersonators.png', 2),
(9, '  magicians Magicians', 'What happens when magicians do their thing? Bunnies start poppin’ outta hats, coins miraculously appear behind peoples’ ears, and good-lookin’ ladies get… sawed in half.', '2013-09-21 13:21:58', 'icon_n_magicians.png', 2),
(10, 'Models & Actors', 'Need to add pizazz to your photo or film shoot? Look no further than these talented (and most likely good-lookin’) actors and models. They’ll be sure to make your production shine like the Hollywood sun.', '2013-09-21 13:22:23', 'icon_n_models_actors.png', 2),
(11, 'Musicians', 'Check out our talented solo musicians to bring the perfect touch of intimacy to your event. From accordions to ukuleles, from bagpipes to violins… you can find ‘em all here!', '2013-09-21 13:22:47', 'icon_n_musicians.png', 2),
(12, 'Singers', 'Tell us what your ears are craving… Crooners? Soul sistas? Operatic divas? Down-home country boys? Just take your pick. We got ‘em all…', '2013-09-21 13:23:08', 'icon_n_singers.png', 2),
(13, 'Speakers', 'Raise your hand if you’ve ever fallen asleep during a boring lecture or presentation. Keep your guests bright-eyed by hiring one of these dynamic speakers that are bound to educate, motivate, and engage!', '2013-09-21 13:23:32', 'icon_n_speakers.png', 2),
(14, 'Specialty Entertainment', 'Right now you might be thinking: what’s so “special” about these performers? If you’re looking for something memorable that’s unique and perhaps even off-the-beaten-path… sneak a peek at some of these acts.', '2013-09-21 13:23:55', 'icon_n_specialty.png', 2),
(15, 'Tribute Bands', 'Give yourself and your guests a front row seat to the next best thing. From ABBA to The Stones, Beatles to The Rat Pack… we’ve got you covered. Start warming up those pipes, because you’re gonna want to sing along.', '2013-09-21 13:24:18', 'icon_n_tributes.png', 2),
(16, ' World & Cultural', 'Ordering Chinese take-out doesn’t qualify you as “cultured.” Hire one of our fabulous internationally-inspired acts and show your guests your cultural side.', '2013-09-21 13:33:43', 'icon_n_world.png', 2),
(17, 'Most Popular', 'Not to say that it’s a popularity contest amongst our hundreds of browsable categories, but these services are the frequent go-to’s when it comes to getting your party started.', '2013-09-21 13:27:20', 'icon_v_professionalservices.png', 3),
(18, 'Wedding Services', 'Unique invitations. Beautiful bouquets. Delicious catered meals and moist, fluffy cake. Amazing wedding singers and reception band. Perfectly captured photos of your big day. No need to thank us… just enjoy your special day.', '2013-09-21 13:28:17', 'icon_e_wedding.png', 3),
(19, 'Beauty & Apparel', 'Get ready to hear some of ultra-classy pickup lines, and maybe a whistle or two, because these services are all about making you look good.', '2013-09-21 13:28:44', 'icon_v_beautyattire.png', 3),
(20, 'Flowers & Decor', 'Take a looksie at these talented florists and decorators. They’ll get you hooked up with some beautiful (and smelly-good) decorations for your event.', '2013-09-21 13:29:31', 'icon_v_flowers.png', 3),
(21, 'Food & Beverage', 'A big juicy steak… Ice-cold drinks… Melt-in-your mouth chocolate cake… Check out these pros to see how they can make your event delicioso!', '2013-09-21 13:30:25', 'icon_v_foodbeverage.png', 3),
(22, 'Outdoor Parties', 'Great weather + cool activities + your peeps = a rip-roarin’ good time! Let these outdoor event specialists help you put together a perfect day of fun in the sun!', '2013-09-21 13:30:55', 'icon_v_outdoor_parties.png', 3),
(23, 'Photo & Video', '“Say cheeeese!” Now put that Polaroid away… it won’t do for this event. Call on these pros to capture great moments at your party or photo session, complete with smiles, laughs, and goofy faces.', '2013-09-21 13:31:22', 'icon_v_photo.png', 3),
(24, 'Production Services', 'Need flames shooting from the stage, state-of-the-art sound, an elaborate set, or a spotlight? Give your audience’s eyes and ears a treat with these behind the scenes pros.', '2013-09-21 13:33:29', 'icon_v_production.png', 3),
(25, 'Professional Services', 'Whew… all this party-plannin’ stuff can be a handful, can’t it? It’s pretty impossible for you to do everything on your own. Let these pros take some of the weight off your shoulders. They know how to get your party started.', '2013-09-21 13:32:16', 'icon_e_community.png', 3),
(26, '  rentals and supplies Rentals & Supplies', 'You can’t expect guests to show up to your event without sending ‘em some sweet invites, and you can’t have a dinner party without tables. Hire pros to work out the logistics so you can let the good times roll.', '2013-09-21 13:34:02', 'icon_v_rentals.png', 3),
(27, 'Transportation Services', 'Not excited about squeaking up to your event in the rusty ol’ ‘69 El Camino? Just leave it in the garage and let these transportation pros help you arrive to your event in style.', '2013-09-21 13:34:31', 'icon_v_transportation.png', 3);

-- --------------------------------------------------------

--
-- Table structure for table `subskill`
--

CREATE TABLE IF NOT EXISTS `subskill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_category_name` varchar(500) NOT NULL,
  `category_id` int(11) NOT NULL,
  `descp` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `indexstatus` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=134 ;

--
-- Dumping data for table `subskill`
--

INSERT INTO `subskill` (`id`, `sub_category_name`, `category_id`, `descp`, `date`, `indexstatus`) VALUES
(1, 'Blues Bands', 1, 'With over 80 different genres of bands and musical groups to choose from, it’s nearly impossible to leave without finding a band that you and your guests will wanna jam to.', '2013-09-21 14:41:27', 1),
(2, 'Country Bands', 1, 'With over 80 different genres of bands and musical groups to choose from, it’s nearly impossible to leave without finding a band that you and your guests will wanna jam to.', '2013-09-21 14:06:59', 0),
(3, 'Cover Bands', 1, 'With over 80 different genres of bands and musical groups to choose from, it’s nearly impossible to leave without finding a band that you and your guests will wanna jam to.', '2013-09-21 14:07:46', 0),
(4, 'Christian Bands', 1, 'With over 80 different genres of bands and musical groups to choose from, it’s nearly impossible to leave without finding a band that you and your guests will wanna jam to.', '2013-09-21 14:08:11', 0),
(5, 'Folk Bands', 1, 'With over 80 different genres of bands and musical groups to choose from, it’s nearly impossible to leave without finding a band that you and your guests will wanna jam to.', '2013-09-21 14:08:43', 0),
(6, 'Animal Acts', 2, 'There’s nothin’ better than knowing that you’ve made your child’s day, is there? Well… why not make their year (or even their childhood) by throwing a party they’ll never forget with these “rock-your-socks-off” entertainers.', '2013-09-21 14:09:31', 0),
(7, 'Balloon Artists', 2, 'There’s nothin’ better than knowing that you’ve made your child’s day, is there? Well… why not make their year (or even their childhood) by throwing a party they’ll never forget with these “rock-your-socks-off” entertainers.', '2013-09-21 14:09:53', 0),
(8, 'Caricaturist', 2, 'There’s nothin’ better than knowing that you’ve made your child’s day, is there? Well… why not make their year (or even their childhood) by throwing a party they’ll never forget with these “rock-your-socks-off” entertainers.', '2013-09-21 14:10:17', 0),
(9, 'Characters', 2, 'There’s nothin’ better than knowing that you’ve made your child’s day, is there? Well… why not make their year (or even their childhood) by throwing a party they’ll never forget with these “rock-your-socks-off” entertainers.', '2013-09-21 14:10:42', 0),
(10, 'Children''s Music', 2, 'There’s nothin’ better than knowing that you’ve made your child’s day, is there? Well… why not make their year (or even their childhood) by throwing a party they’ll never forget with these “rock-your-socks-off” entertainers.', '2013-09-21 14:11:06', 0),
(11, 'Acrobats', 3, 'Step right up to see the amazing contortionist! Or how about the death-defying trapeze artist? They’re all jaw-dropping, and these performers will dazzle you with three rings of fun.', '2013-09-21 14:11:32', 0),
(12, 'Aerialists', 3, 'Step right up to see the amazing contortionist! Or how about the death-defying trapeze artist? They’re all jaw-dropping, and these performers will dazzle you with three rings of fun.', '2013-09-21 14:11:57', 0),
(13, 'Balloon Twisters', 3, 'Step right up to see the amazing contortionist! Or how about the death-defying trapeze artist? They’re all jaw-dropping, and these performers will dazzle you with three rings of fun.', '2013-09-21 14:41:27', 1),
(14, 'Clowns', 3, 'Step right up to see the amazing contortionist! Or how about the death-defying trapeze artist? They’re all jaw-dropping, and these performers will dazzle you with three rings of fun.', '2013-09-21 14:41:27', 1),
(15, 'Contortionists', 3, 'Step right up to see the amazing contortionist! Or how about the death-defying trapeze artist? They’re all jaw-dropping, and these performers will dazzle you with three rings of fun.', '2013-09-21 14:13:11', 0),
(16, 'Classical Guitarists', 4, 'Dear sir or madam… if you want live classical music at your event, you’ve got class. You know the difference between “real” music and that stuff those hooligans are listening to nowadays.', '2013-09-21 14:13:41', 0),
(17, 'Classical Pianists', 4, 'Dear sir or madam… if you want live classical music at your event, you’ve got class. You know the difference between “real” music and that stuff those hooligans are listening to nowadays.', '2013-09-21 14:14:06', 0),
(18, 'Ensembles', 4, 'Dear sir or madam… if you want live classical music at your event, you’ve got class. You know the difference between “real” music and that stuff those hooligans are listening to nowadays.', '2013-09-21 14:14:38', 0),
(19, 'Flutist', 4, 'Dear sir or madam… if you want live classical music at your event, you’ve got class. You know the difference between “real” music and that stuff those hooligans are listening to nowadays.', '2013-09-21 14:15:01', 0),
(20, 'Handbell Choirs', 4, 'Dear sir or madam… if you want live classical music at your event, you’ve got class. You know the difference between “real” music and that stuff those hooligans are listening to nowadays.', '2013-09-21 14:15:28', 0),
(21, 'Christian Comedian', 5, 'Laughter is the best medicine. So is giggling, chuckling, guffawing, and even the occasional snorting.', '2013-09-21 14:15:57', 0),
(22, 'Clowns', 5, 'Laughter is the best medicine. So is giggling, chuckling, guffawing, and even the occasional snorting.', '2013-09-21 14:16:26', 0),
(23, 'Comedians', 5, 'Laughter is the best medicine. So is giggling, chuckling, guffawing, and even the occasional snorting.', '2013-09-21 14:41:27', 1),
(24, 'Comedy Improv', 5, 'Laughter is the best medicine. So is giggling, chuckling, guffawing, and even the occasional snorting.', '2013-09-21 14:17:11', 0),
(25, 'Comedy Magicians', 5, 'Laughter is the best medicine. So is giggling, chuckling, guffawing, and even the occasional snorting.', '2013-09-21 14:17:37', 0),
(26, 'African Dance', 6, 'You may know how to get jiggy with it, bust out a mean cha-cha slide or even do the robot. Even so, you might want to check out these professional dancers to light up your event.', '2013-09-21 14:18:03', 0),
(27, 'Ballet Dancer', 6, 'You may know how to get jiggy with it, bust out a mean cha-cha slide or even do the robot. Even so, you might want to check out these professional dancers to light up your event.', '2013-09-21 14:18:27', 0),
(28, 'Ballroom Dancer', 6, 'You may know how to get jiggy with it, bust out a mean cha-cha slide or even do the robot. Even so, you might want to check out these professional dancers to light up your event.', '2013-09-21 14:18:50', 0),
(29, 'Belly Dancer', 6, 'You may know how to get jiggy with it, bust out a mean cha-cha slide or even do the robot. Even so, you might want to check out these professional dancers to light up your event.', '2013-09-21 14:19:15', 0),
(30, 'Break Dancer', 6, 'You may know how to get jiggy with it, bust out a mean cha-cha slide or even do the robot. Even so, you might want to check out these professional dancers to light up your event.', '2013-09-21 14:19:37', 0),
(31, 'Bar Mitzvah DJ', 7, 'For a fresh spin on any party, book a DJ to drop beats and get your guests out of their seats and onto the dance floor.', '2013-09-21 14:20:07', 0),
(32, 'Club DJ', 7, 'For a fresh spin on any party, book a DJ to drop beats and get your guests out of their seats and onto the dance floor.', '2013-09-21 14:20:31', 0),
(33, 'Event DJ', 7, 'For a fresh spin on any party, book a DJ to drop beats and get your guests out of their seats and onto the dance floor.', '2013-09-21 14:20:54', 0),
(34, 'Karaoke DJ', 7, 'For a fresh spin on any party, book a DJ to drop beats and get your guests out of their seats and onto the dance floor.', '2013-09-21 14:21:12', 0),
(35, 'Mobile DJ', 7, 'For a fresh spin on any party, book a DJ to drop beats and get your guests out of their seats and onto the dance floor.', '2013-09-21 14:21:36', 0),
(36, 'Barack Obama', 8, '“Thank you… thank you very much.” “Happy birthday, Mr. President.” “Hasta la vista, baby.” Yes… Elvis, Marilyn, and Ah-nold are just waiting to drop these lines at your next event.', '2013-09-21 14:22:07', 0),
(37, 'Barbra Streisand', 8, '“Thank you… thank you very much.” “Happy birthday, Mr. President.” “Hasta la vista, baby.” Yes… Elvis, Marilyn, and Ah-nold are just waiting to drop these lines at your next event.', '2013-09-21 14:22:26', 0),
(38, 'Cher', 8, '“Thank you… thank you very much.” “Happy birthday, Mr. President.” “Hasta la vista, baby.” Yes… Elvis, Marilyn, and Ah-nold are just waiting to drop these lines at your next event.', '2013-09-21 14:22:44', 0),
(39, 'Elton John', 8, '“Thank you… thank you very much.” “Happy birthday, Mr. President.” “Hasta la vista, baby.” Yes… Elvis, Marilyn, and Ah-nold are just waiting to drop these lines at your next event.', '2013-09-21 14:23:12', 0),
(40, 'Elvis Presley', 8, '“Thank you… thank you very much.” “Happy birthday, Mr. President.” “Hasta la vista, baby.” Yes… Elvis, Marilyn, and Ah-nold are just waiting to drop these lines at your next event.', '2013-09-21 14:23:37', 0),
(41, 'Children''s Magic', 9, 'What happens when magicians do their thing? Bunnies start poppin’ outta hats, coins miraculously appear behind peoples’ ears, and good-lookin’ ladies get… sawed in half.', '2013-09-21 14:24:06', 0),
(42, 'Comedy Magicians', 9, 'What happens when magicians do their thing? Bunnies start poppin’ outta hats, coins miraculously appear behind peoples’ ears, and good-lookin’ ladies get… sawed in half.', '2013-09-21 14:24:28', 0),
(43, 'Corporate Magician', 9, 'What happens when magicians do their thing? Bunnies start poppin’ outta hats, coins miraculously appear behind peoples’ ears, and good-lookin’ ladies get… sawed in half.', '2013-09-21 14:24:51', 0),
(44, 'Escape Artist', 9, 'What happens when magicians do their thing? Bunnies start poppin’ outta hats, coins miraculously appear behind peoples’ ears, and good-lookin’ ladies get… sawed in half.', '2013-09-21 14:25:20', 0),
(45, 'Illusionist', 9, 'What happens when magicians do their thing? Bunnies start poppin’ outta hats, coins miraculously appear behind peoples’ ears, and good-lookin’ ladies get… sawed in half.', '2013-09-21 14:25:47', 0),
(46, 'Actor', 10, 'Need to add pizazz to your photo or film shoot? Look no further than these talented (and most likely good-lookin’) actors and models. They’ll be sure to make your production shine like the Hollywood sun.', '2013-09-21 14:26:21', 0),
(47, 'Actress', 10, 'Need to add pizazz to your photo or film shoot? Look no further than these talented (and most likely good-lookin’) actors and models. They’ll be sure to make your production shine like the Hollywood sun.', '2013-09-21 14:26:40', 0),
(48, 'Child Actor', 10, 'Need to add pizazz to your photo or film shoot? Look no further than these talented (and most likely good-lookin’) actors and models. They’ll be sure to make your production shine like the Hollywood sun.', '2013-09-21 14:41:27', 1),
(49, 'Child Actress', 10, 'Need to add pizazz to your photo or film shoot? Look no further than these talented (and most likely good-lookin’) actors and models. They’ll be sure to make your production shine like the Hollywood sun.', '2013-09-21 14:27:33', 0),
(50, 'Female Model', 10, 'Need to add pizazz to your photo or film shoot? Look no further than these talented (and most likely good-lookin’) actors and models. They’ll be sure to make your production shine like the Hollywood sun.', '2013-09-21 14:27:52', 0),
(51, 'Accordion Players', 11, 'Check out our talented solo musicians to bring the perfect touch of intimacy to your event. From accordions to ukuleles, from bagpipes to violins… you can find ‘em all here!', '2013-09-21 14:28:25', 0),
(52, 'Bagpiper', 11, 'Check out our talented solo musicians to bring the perfect touch of intimacy to your event. From accordions to ukuleles, from bagpipes to violins… you can find ‘em all here!', '2013-09-21 14:41:27', 1),
(53, 'Bass Players', 11, 'Check out our talented solo musicians to bring the perfect touch of intimacy to your event. From accordions to ukuleles, from bagpipes to violins… you can find ‘em all here!', '2013-09-21 14:29:03', 0),
(54, 'Drummers', 11, 'Check out our talented solo musicians to bring the perfect touch of intimacy to your event. From accordions to ukuleles, from bagpipes to violins… you can find ‘em all here!', '2013-09-21 14:29:29', 0),
(55, 'Flutists', 11, 'Check out our talented solo musicians to bring the perfect touch of intimacy to your event. From accordions to ukuleles, from bagpipes to violins… you can find ‘em all here!', '2013-09-21 14:29:55', 0),
(56, 'A Cappella Group', 12, 'Tell us what your ears are craving… Crooners? Soul sistas? Operatic divas? Down-home country boys? Just take your pick. We got ‘em all…', '2013-09-21 14:30:25', 0),
(57, 'Barbershop', 12, 'Tell us what your ears are craving… Crooners? Soul sistas? Operatic divas? Down-home country boys? Just take your pick. We got ‘em all…', '2013-09-21 14:30:44', 0),
(58, 'Choir', 12, 'Tell us what your ears are craving… Crooners? Soul sistas? Operatic divas? Down-home country boys? Just take your pick. We got ‘em all…', '2013-09-21 14:31:05', 0),
(59, 'Crooner', 12, 'Tell us what your ears are craving… Crooners? Soul sistas? Operatic divas? Down-home country boys? Just take your pick. We got ‘em all…', '2013-09-21 14:31:32', 0),
(60, 'Doo Wop', 12, 'Tell us what your ears are craving… Crooners? Soul sistas? Operatic divas? Down-home country boys? Just take your pick. We got ‘em all…', '2013-09-21 14:41:27', 1),
(61, 'Arts / Entertainment ', 13, 'Raise your hand if you’ve ever fallen asleep during a boring lecture or presentation. Keep your guests bright-eyed by hiring one of these dynamic speakers that are bound to educate, motivate, and engage!', '2013-09-21 14:32:25', 0),
(62, 'Athlete / Sports Speaker', 13, 'Raise your hand if you’ve ever fallen asleep during a boring lecture or presentation. Keep your guests bright-eyed by hiring one of these dynamic speakers that are bound to educate, motivate, and engage!', '2013-09-21 14:35:28', 0),
(63, 'Christian Speaker', 13, 'Raise your hand if you’ve ever fallen asleep during a boring lecture or presentation. Keep your guests bright-eyed by hiring one of these dynamic speakers that are bound to educate, motivate, and engage!', '2013-09-21 14:36:42', 0),
(64, 'Environmentalist / Green Speaker', 13, 'Raise your hand if you’ve ever fallen asleep during a boring lecture or presentation. Keep your guests bright-eyed by hiring one of these dynamic speakers that are bound to educate, motivate, and engage!', '2013-09-21 14:37:24', 0),
(65, 'Motivational Speaker', 13, 'Raise your hand if you’ve ever fallen asleep during a boring lecture or presentation. Keep your guests bright-eyed by hiring one of these dynamic speakers that are bound to educate, motivate, and engage!', '2013-09-21 14:37:56', 0),
(66, 'Auctioneers', 14, 'Right now you might be thinking: what’s so “special” about these performers? If you’re looking for something memorable that’s unique and perhaps even off-the-beaten-path… sneak a peek at some of these acts.', '2013-09-21 14:38:31', 0),
(67, 'Animal Shows', 14, 'Right now you might be thinking: what’s so “special” about these performers? If you’re looking for something memorable that’s unique and perhaps even off-the-beaten-path… sneak a peek at some of these acts.', '2013-09-21 14:38:53', 0),
(68, 'Body Painters', 14, 'Right now you might be thinking: what’s so “special” about these performers? If you’re looking for something memorable that’s unique and perhaps even off-the-beaten-path… sneak a peek at some of these acts.', '2013-09-21 14:39:19', 0),
(69, 'Fine Artists', 14, 'Right now you might be thinking: what’s so “special” about these performers? If you’re looking for something memorable that’s unique and perhaps even off-the-beaten-path… sneak a peek at some of these acts.', '2013-09-21 14:39:52', 0),
(70, 'Game Shows', 14, 'Right now you might be thinking: what’s so “special” about these performers? If you’re looking for something memorable that’s unique and perhaps even off-the-beaten-path… sneak a peek at some of these acts.', '2013-09-21 14:40:13', 0),
(71, 'Beach Boys', 15, 'Give yourself and your guests a front row seat to the next best thing. From ABBA to The Stones, Beatles to The Rat Pack… we’ve got you covered. Start warming up those pipes, because you’re gonna want to sing along.', '2013-09-21 15:05:28', 0),
(72, 'Beatles', 15, 'Give yourself and your guests a front row seat to the next best thing. From ABBA to The Stones, Beatles to The Rat Pack… we’ve got you covered. Start warming up those pipes, because you’re gonna want to sing along.', '2013-09-21 15:05:59', 0),
(73, 'Blues Brothers', 15, 'Give yourself and your guests a front row seat to the next best thing. From ABBA to The Stones, Beatles to The Rat Pack… we’ve got you covered. Start warming up those pipes, because you’re gonna want to sing along.', '2013-09-21 15:06:19', 0),
(74, 'Bon Jovi', 15, 'Give yourself and your guests a front row seat to the next best thing. From ABBA to The Stones, Beatles to The Rat Pack… we’ve got you covered. Start warming up those pipes, because you’re gonna want to sing along.', '2013-09-21 15:06:47', 0),
(75, 'Eagles', 15, 'Give yourself and your guests a front row seat to the next best thing. From ABBA to The Stones, Beatles to The Rat Pack… we’ve got you covered. Start warming up those pipes, because you’re gonna want to sing along.', '2013-09-21 15:07:08', 0),
(76, 'African', 16, 'Ordering Chinese take-out doesn’t qualify you as “cultured.” Hire one of our fabulous internationally-inspired acts and show your guests your cultural side.', '2013-09-21 15:07:58', 0),
(77, 'Asian', 16, 'Ordering Chinese take-out doesn’t qualify you as “cultured.” Hire one of our fabulous internationally-inspired acts and show your guests your cultural side.', '2013-09-21 15:08:21', 0),
(78, 'Australian', 16, 'Ordering Chinese take-out doesn’t qualify you as “cultured.” Hire one of our fabulous internationally-inspired acts and show your guests your cultural side.', '2013-09-21 15:08:41', 0),
(79, 'Cajun', 16, 'Ordering Chinese take-out doesn’t qualify you as “cultured.” Hire one of our fabulous internationally-inspired acts and show your guests your cultural side.', '2013-09-21 15:09:01', 0),
(80, 'Calypso', 16, 'Ordering Chinese take-out doesn’t qualify you as “cultured.” Hire one of our fabulous internationally-inspired acts and show your guests your cultural side.', '2013-09-21 15:09:32', 0),
(81, 'Balloon Artists', 17, 'Not to say that it’s a popularity contest amongst our hundreds of browsable categories, but these services are the frequent go-to’s when it comes to getting your party started.', '2013-09-21 15:10:34', 0),
(82, 'Bands', 17, 'Not to say that it’s a popularity contest amongst our hundreds of browsable categories, but these services are the frequent go-to’s when it comes to getting your party started.', '2013-09-21 15:11:09', 0),
(83, 'Bartender', 17, 'Not to say that it’s a popularity contest amongst our hundreds of browsable categories, but these services are the frequent go-to’s when it comes to getting your party started.', '2013-09-21 15:11:31', 0),
(84, 'Bounce Houses', 17, 'Not to say that it’s a popularity contest amongst our hundreds of browsable categories, but these services are the frequent go-to’s when it comes to getting your party started.', '2013-09-21 15:11:55', 0),
(85, 'Caterers', 17, 'Not to say that it’s a popularity contest amongst our hundreds of browsable categories, but these services are the frequent go-to’s when it comes to getting your party started.', '2013-09-21 15:45:36', 1),
(86, 'Wedding Cakes', 18, 'Unique invitations. Beautiful bouquets. Delicious catered meals and moist, fluffy cake. Amazing wedding singers and reception band. Perfectly captured photos of your big day. No need to thank us… just enjoy your special day.', '2013-09-21 15:12:57', 0),
(87, 'Wedding Dresses', 18, 'Unique invitations. Beautiful bouquets. Delicious catered meals and moist, fluffy cake. Amazing wedding singers and reception band. Perfectly captured photos of your big day. No need to thank us… just enjoy your special day.', '2013-09-21 15:13:34', 0),
(88, 'Entertainment', 18, 'Unique invitations. Beautiful bouquets. Delicious catered meals and moist, fluffy cake. Amazing wedding singers and reception band. Perfectly captured photos of your big day. No need to thank us… just enjoy your special day.', '2013-09-21 15:45:36', 1),
(89, 'Wedding Favors', 18, 'Unique invitations. Beautiful bouquets. Delicious catered meals and moist, fluffy cake. Amazing wedding singers and reception band. Perfectly captured photos of your big day. No need to thank us… just enjoy your special day.', '2013-09-21 15:14:17', 0),
(90, 'Wedding Florists', 18, 'Unique invitations. Beautiful bouquets. Delicious catered meals and moist, fluffy cake. Amazing wedding singers and reception band. Perfectly captured photos of your big day. No need to thank us… just enjoy your special day.', '2013-09-21 15:14:50', 0),
(91, 'Costumes', 19, 'Get ready to hear some of ultra-classy pickup lines, and maybe a whistle or two, because these services are all about making you look good.', '2013-09-21 15:15:20', 0),
(92, 'Gowns & Dresses', 19, 'Get ready to hear some of ultra-classy pickup lines, and maybe a whistle or two, because these services are all about making you look good.', '2013-09-21 15:15:50', 0),
(93, 'Hair Stylists', 19, 'Get ready to hear some of ultra-classy pickup lines, and maybe a whistle or two, because these services are all about making you look good.', '2013-09-21 15:45:36', 1),
(94, 'Makeup Artists', 19, 'Get ready to hear some of ultra-classy pickup lines, and maybe a whistle or two, because these services are all about making you look good.', '2013-09-21 15:16:47', 0),
(95, 'Tuxedos & Suits', 19, 'Get ready to hear some of ultra-classy pickup lines, and maybe a whistle or two, because these services are all about making you look good.', '2013-09-21 15:17:06', 0),
(96, 'Balloon Decor', 20, 'Take a looksie at these talented florists and decorators. They’ll get you hooked up with some beautiful (and smelly-good) decorations for your event.', '2013-09-21 15:17:42', 0),
(97, 'Event Florists', 20, 'Take a looksie at these talented florists and decorators. They’ll get you hooked up with some beautiful (and smelly-good) decorations for your event.', '2013-09-21 15:18:03', 0),
(98, 'Party Decor', 20, 'Take a looksie at these talented florists and decorators. They’ll get you hooked up with some beautiful (and smelly-good) decorations for your event.', '2013-09-21 15:45:36', 1),
(99, 'Props for Parties', 20, 'Take a looksie at these talented florists and decorators. They’ll get you hooked up with some beautiful (and smelly-good) decorations for your event.', '2013-09-21 15:18:54', 0),
(100, 'Bartenders', 21, 'A big juicy steak… Ice-cold drinks… Melt-in-your mouth chocolate cake… Check out these pros to see how they can make your event delicioso!', '2013-09-21 15:45:37', 1),
(101, 'Cakes for Parties', 21, 'A big juicy steak… Ice-cold drinks… Melt-in-your mouth chocolate cake… Check out these pros to see how they can make your event delicioso!', '2013-09-21 15:19:51', 0),
(102, 'Caterer', 21, 'A big juicy steak… Ice-cold drinks… Melt-in-your mouth chocolate cake… Check out these pros to see how they can make your event delicioso!', '2013-09-21 15:20:25', 0),
(103, 'Concessions', 21, 'A big juicy steak… Ice-cold drinks… Melt-in-your mouth chocolate cake… Check out these pros to see how they can make your event delicioso!', '2013-09-21 15:20:44', 0),
(104, 'Flair Bartenders', 21, 'A big juicy steak… Ice-cold drinks… Melt-in-your mouth chocolate cake… Check out these pros to see how they can make your event delicioso!', '2013-09-21 15:21:22', 0),
(105, 'Bounce Houses', 22, 'Great weather + cool activities + your peeps = a rip-roarin’ good time! Let these outdoor event specialists help you put together a perfect day of fun in the sun!', '2013-09-21 15:21:49', 0),
(106, 'Carnival Games', 22, 'Great weather + cool activities + your peeps = a rip-roarin’ good time! Let these outdoor event specialists help you put together a perfect day of fun in the sun!', '2013-09-21 15:45:37', 1),
(107, 'Carnival Rides', 22, 'Great weather + cool activities + your peeps = a rip-roarin’ good time! Let these outdoor event specialists help you put together a perfect day of fun in the sun!', '2013-09-21 15:22:45', 0),
(108, 'Outdoor Movies', 22, 'Great weather + cool activities + your peeps = a rip-roarin’ good time! Let these outdoor event specialists help you put together a perfect day of fun in the sun!', '2013-09-21 15:23:16', 0),
(109, 'Petting Zoos', 22, 'Great weather + cool activities + your peeps = a rip-roarin’ good time! Let these outdoor event specialists help you put together a perfect day of fun in the sun!', '2013-09-21 15:23:51', 0),
(110, 'Event Photographers', 23, '“Say cheeeese!” Now put that Polaroid away… it won’t do for this event. Call on these pros to capture great moments at your party or photo session, complete with smiles, laughs, and goofy faces.', '2013-09-21 15:24:30', 0),
(111, 'Headshots', 23, '“Say cheeeese!” Now put that Polaroid away… it won’t do for this event. Call on these pros to capture great moments at your party or photo session, complete with smiles, laughs, and goofy faces.', '2013-09-21 15:24:51', 0),
(112, 'Photo Booths', 23, '“Say cheeeese!” Now put that Polaroid away… it won’t do for this event. Call on these pros to capture great moments at your party or photo session, complete with smiles, laughs, and goofy faces.', '2013-09-21 15:25:12', 0),
(113, 'Portrait Photographers', 23, '“Say cheeeese!” Now put that Polaroid away… it won’t do for this event. Call on these pros to capture great moments at your party or photo session, complete with smiles, laughs, and goofy faces.', '2013-09-21 15:25:45', 0),
(114, 'Wedding Photographer', 23, '“Say cheeeese!” Now put that Polaroid away… it won’t do for this event. Call on these pros to capture great moments at your party or photo session, complete with smiles, laughs, and goofy faces.', '2013-09-21 15:26:20', 0),
(115, 'Laser Shows', 24, 'Need flames shooting from the stage, state-of-the-art sound, an elaborate set, or a spotlight? Give your audience’s eyes and ears a treat with these behind the scenes pros.', '2013-09-21 15:26:58', 0),
(116, 'Lighting', 24, 'Need flames shooting from the stage, state-of-the-art sound, an elaborate set, or a spotlight? Give your audience’s eyes and ears a treat with these behind the scenes pros.', '2013-09-21 15:27:20', 0),
(117, 'Pyrotechnics', 24, 'Need flames shooting from the stage, state-of-the-art sound, an elaborate set, or a spotlight? Give your audience’s eyes and ears a treat with these behind the scenes pros.', '2013-09-21 15:27:50', 0),
(118, 'Set Designers', 24, 'Need flames shooting from the stage, state-of-the-art sound, an elaborate set, or a spotlight? Give your audience’s eyes and ears a treat with these behind the scenes pros.', '2013-09-21 15:28:13', 0),
(119, 'Sound Technicians', 24, 'Need flames shooting from the stage, state-of-the-art sound, an elaborate set, or a spotlight? Give your audience’s eyes and ears a treat with these behind the scenes pros.', '2013-09-21 15:28:45', 0),
(120, 'Airbrush Artists', 25, 'Whew… all this party-plannin’ stuff can be a handful, can’t it? It’s pretty impossible for you to do everything on your own. Let these pros take some of the weight off your shoulders. They know how to get your party started.', '2013-09-21 15:29:15', 0),
(121, 'Auctioneers', 25, 'Whew… all this party-plannin’ stuff can be a handful, can’t it? It’s pretty impossible for you to do everything on your own. Let these pros take some of the weight off your shoulders. They know how to get your party started.', '2013-09-21 15:29:40', 0),
(122, 'Body Painters', 25, 'Whew… all this party-plannin’ stuff can be a handful, can’t it? It’s pretty impossible for you to do everything on your own. Let these pros take some of the weight off your shoulders. They know how to get your party started.', '2013-09-21 15:30:09', 0),
(123, 'Dance Instructors', 25, 'Whew… all this party-plannin’ stuff can be a handful, can’t it? It’s pretty impossible for you to do everything on your own. Let these pros take some of the weight off your shoulders. They know how to get your party started.', '2013-09-21 15:30:32', 0),
(124, 'Event Planners', 25, 'Whew… all this party-plannin’ stuff can be a handful, can’t it? It’s pretty impossible for you to do everything on your own. Let these pros take some of the weight off your shoulders. They know how to get your party started.', '2013-09-21 15:31:04', 0),
(125, 'Costumes', 26, 'You can’t expect guests to show up to your event without sending ‘em some sweet invites, and you can’t have a dinner party without tables. Hire pros to work out the logistics so you can let the good times roll.', '2013-09-21 15:31:43', 0),
(126, 'Casino Games', 26, 'You can’t expect guests to show up to your event without sending ‘em some sweet invites, and you can’t have a dinner party without tables. Hire pros to work out the logistics so you can let the good times roll.', '2013-09-21 15:32:05', 0),
(127, 'Invitations', 26, 'You can’t expect guests to show up to your event without sending ‘em some sweet invites, and you can’t have a dinner party without tables. Hire pros to work out the logistics so you can let the good times roll.', '2013-09-21 15:32:25', 0),
(128, 'Linens/Chair Covers', 26, 'You can’t expect guests to show up to your event without sending ‘em some sweet invites, and you can’t have a dinner party without tables. Hire pros to work out the logistics so you can let the good times roll.', '2013-09-21 15:32:49', 0),
(129, 'Event Furnishings', 26, 'You can’t expect guests to show up to your event without sending ‘em some sweet invites, and you can’t have a dinner party without tables. Hire pros to work out the logistics so you can let the good times roll.', '2013-09-21 15:33:20', 0),
(130, 'Chauffeurs', 27, 'Not excited about squeaking up to your event in the rusty ol’ ‘69 El Camino? Just leave it in the garage and let these transportation pros help you arrive to your event in style.', '2013-09-21 15:34:04', 0),
(131, 'Horse Drawn Carriage', 27, 'Not excited about squeaking up to your event in the rusty ol’ ‘69 El Camino? Just leave it in the garage and let these transportation pros help you arrive to your event in style.', '2013-09-21 15:34:24', 0),
(132, 'Limo Services', 27, 'Not excited about squeaking up to your event in the rusty ol’ ‘69 El Camino? Just leave it in the garage and let these transportation pros help you arrive to your event in style.', '2013-09-21 15:34:48', 0),
(133, 'Party Buses', 27, 'Not excited about squeaking up to your event in the rusty ol’ ‘69 El Camino? Just leave it in the garage and let these transportation pros help you arrive to your event in style.', '2013-09-21 15:35:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE IF NOT EXISTS `type` (
  `slno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `priority` int(11) NOT NULL,
  `image` varchar(500) NOT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`slno`, `name`, `priority`, `image`) VALUES
(1, 'Live music', 5, 'livemusic.jpeg'),
(2, 'Entertainment', 2, 'entertainment.jpeg'),
(3, 'Event Services', 3, 'eventservice.jpeg'),
(4, 'Speakers', 4, 'speakers.jpeg'),
(6, 'Party Ideas', 6, 'entertainment.jpeg');
